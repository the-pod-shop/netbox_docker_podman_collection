install requirements
=========

a role to install the requirements on the host

example
----------------
```yaml

- name: requirements
  import_role:
    name: ji_podhead.netbox_docker_podman.install_requirements
```
License
-------

BSD

Author Information
------------------

ji_podhead