init_netbox_folder
=========

clones the netbox-docker repo into the /tmp folder of the host and removes an existing folder

usage
----------------

```yaml
- name: init folder
    import_role:
    name: ji_podhead.netbox_docker_podman.init_netbox_folder
```

License
-------

BSD

Author Information
------------------

ji_podhead