up
=========

deploys the containers, networks and volumes using docker/podman compose

usage
----------------

```yaml

- name: up
  import_role:
    name: ji_podhead.netbox_docker_podman.up
```

License
-------

BSD

Author Information
------------------

ji_podhead